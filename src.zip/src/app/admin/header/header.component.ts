import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { User } from '../../user';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
@Input() pageName: string;
@Input() userName: User;

  constructor(private authService: AuthService, private router: Router) { }
  ngOnInit(): void {

    // this.userName =   ;
  }
  clickMenu(name) {
    switch(name){
      case 'admin': {
        //  this.router.navigateByUrl('/admin'); 
        this.router.navigate(['/admin']);
        break;
      }

      case 'logout': {
        this.router.navigateByUrl('/logon'); 
        // this.router.navigate(['../logon']);
        // this.logout;
        break;
     }
     case 'about': {
      this.router.navigateByUrl('/about'); 
      break;
   }

    }
  }
  logout(){
    this.authService.logout();
    this.router.navigateByUrl('/logon'); //name was /login
  }

}
