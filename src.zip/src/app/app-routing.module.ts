import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { LogonComponent } from './logon/logon.component';
import { AdminComponent } from './admin/admin.component';
import { AboutComponent } from './about/about.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  { path: ' ', pathMatch: 'full', redirectTo: 'logon'},
  { path: 'logon', component: LogonComponent },
  { path: 'admin', component: AdminComponent},
  { path: 'about', component: AboutComponent},
  { path: 'register', component: RegisterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
