import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { CustomValidators } from '../logon/sign-up-validator';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})


export class RegisterComponent implements OnInit {
  pageName : string;
  constructor(private authService: AuthService, private router: Router, private formBuilder: FormBuilder) { }

  registerForm: FormGroup;
  isSubmitted = false;

  

  ngOnInit(): void {
    this.pageName = 'Register';
    this.registerForm = this.formBuilder.group({
      // tel: ['', [Validators.required
      //             ]],
      tel: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      address: ["", Validators.compose([Validators.required, CustomValidators.patternValidator(/\d/,{hasNumber: true})])],

      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5), CustomValidators.patternValidator(/\d/,{hasNumber: true})]],

      email: ['', Validators.compose([Validators.email,Validators.required]) ],

      firstName: ['', Validators.required ],
      lastName: ['', Validators.required ],
      city: ['', Validators.required ],
      country: ['', Validators.required ],
      state: ['', Validators.required ]




      // password: ['', Validators.compose
      // ([
      //     Validators.required,
      //     CustomValidators.patternValidator(/\d/,{hasNumber: true}),
      //     CustomValidators.patternValidator(/[A-Z]/,{hasCapitalCase: true }),
      //     CustomValidators.patternValidator(/[ !@#$%^&()_+\-=\[\]{};':"\\|,.<>\/?]/,{ hasSpecialCharacters: true }),
          
      // ]) ]
      
      
      });
      
  }

  get formControls() {
    return this.registerForm.controls;
  }

  register(registerForm) {
    console.log(this.registerForm.value);
    this.isSubmitted = true;
    if(registerForm.valid) {
      this.router.navigate(['/admin']);
    }

  }

  group = '';
  team = '';
  groups: any[] = [
    {
      groupName: 'United States',
      teams: [
        {
          teamName: 'New York',
        },
        {
          teamName: 'California',
      
        },
        {
          teamName: 'Texas',
       
        },
        {
          teamName: 'Pennslyvania',
       
        },
      ]
    },
    {
      groupName: 'Canada',
      teams: [
        {
          teamName: 'Alberta',
      
        },
        {
          teamName: 'British Columbia',
     
        },
        {
          teamName: 'Ontario',
     
        },
        {
          teamName: 'Quebec',
    
        },
      ]
    },
  ];
  teams: any[] = [];

  showTeams(e: any) {
    this.teams = e.value.teams;
  }




}













// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { Router } from '@angular/router';
// import { AuthService } from '../auth.service';
// import { CustomValidators } from '../logon/sign-up-validator';
// import {FormControl} from '@angular/forms';

// @Component({
//   selector: 'app-register',
//   templateUrl: './register.component.html',
//   styleUrls: ['./register.component.scss']
// })


// export class RegisterComponent implements OnInit {
//   pageName : string;
//   constructor(private authService: AuthService, private router: Router, private formBuilder: FormBuilder) { }

//   registerForm: FormGroup;
//   isSubmitted = false;

//   ngOnInit(): void {
//     this.pageName = 'Register';
//     this.registerForm = this.formBuilder.group({
//       tel: ['', [Validators.required, Validators.pattern("^[0-9]*$"),
//                   Validators.minLength(10), Validators.maxLength(9)]],
//       address: ["", Validators.compose([Validators.required, CustomValidators.patternValidator(/\d/,{hasNumber: true})])],

//       zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5), CustomValidators.patternValidator(/\d/,{hasNumber: true})]],

//       email: ['', Validators.compose([Validators.email,Validators.required]) ],

//       name: ['', Validators.required ],

//       password: ['', Validators.compose
//       ([
//           Validators.required,
//           CustomValidators.patternValidator(/\d/,{hasNumber: true}),
//           CustomValidators.patternValidator(/[A-Z]/,{hasCapitalCase: true }),
//           CustomValidators.patternValidator(/[ !@#$%^&()_+\-=\[\]{};':"\\|,.<>\/?]/,{ hasSpecialCharacters: true }),
          
//       ]) ]
      
      
//       });
//   }

//   countryControl = new FormControl('', Validators.required);
//   statesControl = new FormControl('', Validators.required );
//   selectFormControl = new FormControl('', Validators.required);

  
//   countryList: Array<any> = [
//     { name: '-Select-', states: ['-Any-'] },
//     { name: 'United States', states: ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT'] },
//     { name: 'India', states: ['AP', 'AR', 'AS', 'BR', 'CG', 'CH', 'DL'] },
//     { name: 'Canada', states: ['AB', 'BC', 'MB', 'NB', 'NL', 'NT', 'NS'] },
//     { name: 'United States', states: ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT'] },
//   ];

//   states: Array<any>;
//   changeCountry(count) {
//     this.states = this.countryList.find(con => con.name == count).states;
//   }

//   get formControls() {
//     return this.registerForm.controls;
//   }

//   register(registerForm) {
//     console.log(this.registerForm.value);
//     this.isSubmitted = true;
//     if(registerForm.valid) {
//       this.router.navigate(['/admin']);
//     }

//   }

// }

