import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
// import { User } from '../user';
import { AuthService } from '../auth.service';
import { CustomValidators } from './sign-up-validator';

@Component({
  selector: 'app-logon',
  templateUrl: './logon.component.html',
  styleUrls: ['./logon.component.scss']
})
export class LogonComponent implements OnInit {
  pageName : string;
  constructor(private authService: AuthService, private router: Router, private formBuilder: FormBuilder) { }

  loginForm: FormGroup;
  isSubmitted = false;


  ngOnInit() {
    this.pageName = 'Login';
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.compose([Validators.email,Validators.required]) ],

      

      password: ['', Validators.compose
      ([
          Validators.required,
          CustomValidators.patternValidator(/\d/,{hasNumber: true}),
          CustomValidators.patternValidator(/[A-Z]/,{hasCapitalCase: true }),
          CustomValidators.patternValidator(/[ !@#$%^&()_+\-=\[\]{};':"\\|,.<>\/?]/,{ hasSpecialCharacters: true }),
          // Validators.minLength(8)
      ]) ]
      // confirmPassword:[null, Validators.compose([Validators.required])]
      
      
      });
  }
  clickButton(name) {
    switch(name){
      case 'register': {
        this.router.navigate(['/register']);
        break;
      }

    }
  }

  get formControls() {
    return this.loginForm.controls;
  }

  login(loginForm) {
    console.log(this.loginForm.value);
    this.isSubmitted = true;
    if(loginForm.valid) {
      this.router.navigate(['/admin']);
    }

    // this.authService.login(this.loginForm.value);
    // this.router.navigateByUrl('/admin');
    
  } 


}
